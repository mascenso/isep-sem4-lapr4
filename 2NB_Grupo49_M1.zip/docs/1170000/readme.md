# Student: John Doe - 1170000

## Developed Tasks


| Sprint | Task     |
|--------|--------------------|
| **A**  | [US G002](../us_g002/readme.md) |
| **B**  | [US 1001](../us_1001/readme.md) |
| **C**  | [US 3004](../us_3004/readme.md) |
