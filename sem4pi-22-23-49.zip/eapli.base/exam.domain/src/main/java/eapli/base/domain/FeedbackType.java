package eapli.base.domain;

public enum FeedbackType {
    NONE,
    ON_SUBMISSION,
    AFTER_CLOSING;
}
