package eapli.base.domain;

public enum GradeType {
    NONE,
    ON_SUBMISSION,
    AFTER_CLOSING;
}
