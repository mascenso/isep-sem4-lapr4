package eapli.base.domain;

public enum QuestionType {
    MATCHING,
    MULTIPLE_CHOICE,
    SHORT_ANSWER,
    NUMERICAL,
    SELECT_MISSING_WORDS,
    TRUE_FALSE;
}
