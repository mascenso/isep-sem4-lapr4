package eapli.base.domain;

public enum CourseState {
    OPEN,
    CLOSE,
    ENROLL,
    PROGRESS
}
