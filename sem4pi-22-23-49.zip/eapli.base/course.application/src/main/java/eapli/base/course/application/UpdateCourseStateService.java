package eapli.base.course.application;

import eapli.base.domain.Course;
import eapli.base.repositories.CourseRepository;

public class UpdateCourseStateService {


    private CourseRepository courseRepository;


}
