# Student: Miguel Seixas - 1100358

## Developed Tasks


| Sprint | Task                                                              |
|--------|-------------------------------------------------------------------|
| **B**  | [US 1003](../us_g002/readme.md)                                   |
| **B**  | [US 1008](../SPRINT%20B/template-US/readme.md)                    |
| **B**  | [US 1010](../SPRINT%20B/US_1002-%20Create%20a%20Course/readme.md) |
| **B**  | [US 2002](../SPRINT%20B/US_1002-%20Create%20a%20Course/readme.md) |