# Student: Patricia Teixeira - 1210857

## Developed Tasks


| Sprint | Task                                     |
|--------|------------------------------------------|
| **B**  | [US 1007](../SPRINT B/US_1007/readme.md) |
| **B**  | [US 1009](../SPRINT B/US_1009/readme.md) |
| **B**  | [US 2001](../SPRINT%20B/US2001-Create%20an%20Exam/readme.md) |
| **B**  | [US 3003](../SPRINT B/US_3003/readme.md) |
| **B**  | [US 4001](../SPRINT B/US_4001/readme.md) |

