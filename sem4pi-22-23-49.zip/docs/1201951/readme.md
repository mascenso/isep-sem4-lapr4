# Student: Miguel Cardoso - 1201951

## Developed Tasks


| Sprint | Task                            |
|--------|---------------------------------|
| **B**  | [US 1002](../SPRINT%20B/US_1002-%20Create%20a%20Course/readme.md) |
| **B**  | [US 1012](../US_1012/readme.md) |
| **B**  | [US 3001](../US_3001/readme.md) |
| **B**  | [US 2008](../US_2008/readme.md) |
| **B**  | [US 1006](../US_1006/readme.md) |
| **B**  | [US 1003](../US_1003/readme.md) |

