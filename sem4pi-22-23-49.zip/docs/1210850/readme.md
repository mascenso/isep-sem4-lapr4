# Student: Duarte Fonseca - 1210850

## Developed Tasks


| Sprint | Task                                       |
|--------|--------------------------------------------|
| **B**  | [US 1004](../SPRINT%20B/US_1004/readme.md) |
| **B**  | [US 2007](../US_2007/readme.md)            |
| **B**  | [US 3002](../US_3002/readme.md)            |
| **B**  | [US 5001](../US_5001/readme.md)            |