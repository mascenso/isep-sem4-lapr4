### Glossary

| English |  Portuguese | Description | 
| --- | --- | --- |
| Pandemic | Pandemia | A disease outbreak|
|lockdowns |Confinamento | Refers to a measure of movement restriction.|
|
