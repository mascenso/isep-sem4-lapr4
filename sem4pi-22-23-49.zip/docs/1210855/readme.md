# Student: Mariana Rocha - 1210855

## Developed Tasks


| Sprint | Task                                                                    |
|--------|-------------------------------------------------------------------------|
| **B**  | [US 1001](../SPRINT%20B/US_1001-RegisterSystemUsers/readme.md)          |
| **B**  | [US 1005](../SPRINT%20B/US_1005-SetTeachersOfaCourse/readme.md)         |
| **B**  | [US 1011](../SPRINT%20B/US_1011-ScheduleAnExtraordinaryClass/readme.md) |
| **B**  | [US 2003](../SPRINT%20B/US_2003-ListAllExamsInaCourse/readme.md)        |
