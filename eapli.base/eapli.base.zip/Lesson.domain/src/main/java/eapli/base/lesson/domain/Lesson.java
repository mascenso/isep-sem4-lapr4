package eapli.base.lesson.domain;

public class Lesson {
}
